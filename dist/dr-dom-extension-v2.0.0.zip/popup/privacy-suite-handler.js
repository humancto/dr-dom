/**
 * Privacy Suite Handler for Dr. DOM
 */

(function() {
  // Wait for DOM to be ready
  function initPrivacySuite() {
    console.log('🛡️ Initializing Privacy Suite...');
    
    // Load privacy stats
    loadPrivacyStats();
    
    // Setup toggle handlers
    setupToggles();
    
    // Setup fun feature buttons
    setupFunButtons();
    
    // Update stats every 2 seconds
    setInterval(loadPrivacyStats, 2000);
  }
  
  function loadPrivacyStats() {
    // Get stats from storage
    chrome.storage.local.get(['globalPrivacyStats'], (result) => {
      if (result.globalPrivacyStats) {
        const stats = result.globalPrivacyStats;
        updateElement('trackersBlocked', stats.trackersBlocked || 0);
        updateElement('cookiesCleaned', stats.cookiesCleaned || 0);
        updateElement('dataValueSaved', `$${(stats.dataValueSaved || 0).toFixed(2)}`);
        
        // Calculate privacy score
        const score = Math.max(0, 100 - (stats.trackersBlocked || 0) - (stats.cookiesCleaned || 0) / 2);
        updateElement('privacyScore', Math.round(score));
      }
    });
  }
  
  function setupToggles() {
    const toggles = [
      { id: 'trackerBlockingToggle', setting: 'trackerBlocking' },
      { id: 'cookieCleaningToggle', setting: 'cookieCleaning' },
      { id: 'webrtcProtectionToggle', setting: 'webrtcProtection' },
      { id: 'fingerprintToggle', setting: 'fingerprintPoisoning' }
    ];
    
    toggles.forEach(toggle => {
      const element = document.getElementById(toggle.id);
      if (element) {
        // Load saved state
        chrome.storage.local.get(['privacyConfig'], (result) => {
          const config = result.privacyConfig || {};
          element.checked = config[toggle.setting] !== false;
        });
        
        // Handle changes
        element.addEventListener('change', (e) => {
          updatePrivacySetting(toggle.setting, e.target.checked);
        });
      }
    });
  }
  
  function updatePrivacySetting(setting, value) {
    chrome.storage.local.get(['privacyConfig'], (result) => {
      const config = result.privacyConfig || {};
      config[setting] = value;
      chrome.storage.local.set({ privacyConfig: config });
      
      // Send to active tab
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, {
            action: 'updatePrivacyConfig',
            config: { [setting]: value }
          });
        }
      });
    });
  }
  
  function setupFunButtons() {
    // Roast button
    const roastBtn = document.getElementById('showRoastBtn');
    if (roastBtn) {
      roastBtn.addEventListener('click', () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, { action: 'showRoast' }, (response) => {
              if (response && response.roasts) {
                showFunOutput('🔥 Website Roast:\n\n' + response.roasts.join('\n\n'));
              } else {
                showFunOutput('🔥 This website has more trackers than a detective agency!');
              }
            });
          }
        });
      });
    }
    
    // Weather button
    const weatherBtn = document.getElementById('weatherReportBtn');
    if (weatherBtn) {
      weatherBtn.addEventListener('click', () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, { action: 'getWeatherReport' }, (response) => {
              if (response && response.weather) {
                const w = response.weather;
                showFunOutput(`${w.weather} Privacy Weather: ${w.temperature}\n${w.conditions}\n\nForecast: ${w.forecast}\n\nAdvice: ${w.advice}`);
              } else {
                showFunOutput('🌤️ Privacy Weather: PARTLY TRACKED\nModerate tracking activity detected!');
              }
            });
          }
        });
      });
    }
    
    // Cookie banner button
    const bannerBtn = document.getElementById('showBannerBtn');
    if (bannerBtn) {
      bannerBtn.addEventListener('click', () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, { action: 'showCookieBanner' });
            showFunOutput('🍪 Cookie banner triggered on the page!');
          }
        });
      });
    }
  }
  
  function showFunOutput(text) {
    const output = document.getElementById('funOutput');
    if (output) {
      output.textContent = text;
      output.style.display = 'block';
      
      // Hide after 5 seconds
      setTimeout(() => {
        output.style.display = 'none';
      }, 5000);
    }
  }
  
  function updateElement(id, value) {
    const element = document.getElementById(id);
    if (element) {
      element.textContent = value;
    }
  }
  
  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPrivacySuite);
  } else {
    initPrivacySuite();
  }
})();