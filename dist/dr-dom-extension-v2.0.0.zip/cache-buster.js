// Cache buster - ensures Chrome loads fresh files
// Build timestamp: ${new Date().toISOString()}
console.log('[Dr. DOM] Extension loaded - Build: ' + new Date().toISOString());